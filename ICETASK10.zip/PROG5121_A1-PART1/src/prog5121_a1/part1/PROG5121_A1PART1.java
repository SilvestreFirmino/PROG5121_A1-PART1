package prog5121_a1.part1;

import javax.swing.JOptionPane;

public class PROG5121_A1PART1 {

    public static void main(String[] args) {
        VerifyUser registeredUser = registerUser();
        boolean loginSuccess = loginUser(registeredUser);
        returnLoginStatus(loginSuccess, registeredUser);
    }

    public static VerifyUser registerUser() {
        VerifyUser tempUser = new VerifyUser();

        String username = "";
        String password = "";
        String cellphoneNumber = "";

        JOptionPane.showMessageDialog(null, "************ User Registration *************");

        String firstName = JOptionPane.showInputDialog("Enter your First name:");
        String lastName = JOptionPane.showInputDialog("Enter your Last name:");

        // Username
        while (true) {
            username = JOptionPane.showInputDialog("Enter your username (must contain an underscore and no more than 5 characters):");
            if (tempUser.checkUserName(username)) {
                JOptionPane.showMessageDialog(null, "Username successfully captured.");
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Username is not correctly formatted.\nPlease ensure it contains an underscore and is no more than five characters.");
            }
        }

        // Password
        while (true) {
            password = JOptionPane.showInputDialog("Enter your Password (at least 8 characters, one uppercase, one number, one special character):");
            if (tempUser.checkPasswordComplexity(password)) {
                JOptionPane.showMessageDialog(null, "Password successfully captured.");
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Password is not correctly formatted. Try again.");
            }
        }

        // Cellphone Number
        while (true) {
            cellphoneNumber = JOptionPane.showInputDialog("Enter your South African cellphone number (+27xxxxxxxxx):");
            if (tempUser.checkCellPhoneNumber(cellphoneNumber)) {
                JOptionPane.showMessageDialog(null, "Cell phone number successfully added.");
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Cell phone number incorrectly formatted or missing international code.");
            }
        }

        JOptionPane.showMessageDialog(null, "************ Registration Complete *************");

        return new VerifyUser(username, password, cellphoneNumber, firstName, lastName);
    }

    public static boolean loginUser(VerifyUser registeredUser) {
        int attempts = 0;

        JOptionPane.showMessageDialog(null, "************ User Login *************");

        while (attempts < 3) {
            String enteredUsername = JOptionPane.showInputDialog("Enter your Username:");
            String enteredPassword = JOptionPane.showInputDialog("Enter your Password:");
            String enteredCell = JOptionPane.showInputDialog("Enter your Cellphone Number:");

            if (registeredUser.authenticateUser(enteredUsername, enteredPassword, enteredCell)) {
                return true;
            } else {
                int triesLeft = 2 - attempts;
                JOptionPane.showMessageDialog(null, "Incorrect details. Attempts left: " + triesLeft);
                attempts++;
            }
        }

        JOptionPane.showMessageDialog(null, "Maximum login attempts reached.");
        return false;
    }

    public static String returnLoginStatus(boolean loginSuccess, VerifyUser user) {
        if (loginSuccess) {
            String welcomeMsg = "Login successful!\nWelcome " + user.getFirstName() + " " + user.getLastName() + ", it is great to see you again!";
            JOptionPane.showMessageDialog(null, welcomeMsg);
            return "Login successful!";
        } else {
            JOptionPane.showMessageDialog(null, "Login failed!\nUsername or password incorrect, please try again.");
            return "Login failed.";
        }
    }
}
